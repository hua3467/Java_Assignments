/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kotala
 */
public class Unicode
{
    public static void main(String[] args)
    {
        for(int i = 0; i < 127; i++)
            System.out.println((char)i);
        
    }
    
}
